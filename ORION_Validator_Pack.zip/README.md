# ORION Validator Pack

1. Установи dfx:
   curl -sSf https://internetcomputer.org/install.sh | sh

2. Запусти:
   chmod +x install.sh
   ./install.sh
